# routers/ms_login.py
from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
import msal, secrets, time

from core.settings import settings
from db import get_db
from models.models_rbac import User, UserStatus
from services.security import create_access_token

router = APIRouter(prefix="/auth/microsoft", tags=["auth:microsoft"])

AUTHORITY   = f"https://login.microsoftonline.com/{settings.AZURE_TENANT_ID}"
CLIENT_ID   = settings.AZURE_CLIENT_ID
CLIENT_SEC  = settings.AZURE_CLIENT_SECRET
REDIRECT_URI= settings.AZURE_REDIRECT_URI
SCOPES      = ["openid", "profile", "email", "offline_access"]

def _build_msal_app():
    return msal.ConfidentialClientApplication(
        client_id=CLIENT_ID,
        client_credential=CLIENT_SEC,
        authority=AUTHORITY,
    )

@router.get("/login")
def ms_login(request: Request):
    # gere um state/nonce p/ CSRF e replay
    state = secrets.token_urlsafe(16)
    nonce = secrets.token_urlsafe(16)

    # guarde nos cookies de forma simples (ou SessionMiddleware)
    response = RedirectResponse(url="/")  # placeholder só p/ set_cookie, será sobrescrito abaixo
    response.set_cookie("ms_state", state, max_age=300, httponly=True, samesite="lax")
    response.set_cookie("ms_nonce", nonce, max_age=300, httponly=True, samesite="lax")

    app = _build_msal_app()
    auth_url = app.get_authorization_request_url(
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI,
        state=state,
        prompt="select_account",   # ou "login"
        nonce=nonce,
        response_type="code",
        response_mode="query",
    )
    return RedirectResponse(auth_url)

@router.get("/callback")
def ms_callback(request: Request, db: Session = Depends(get_db), state: str | None = None, code: str | None = None, error: str | None = None):
    if error:
        raise HTTPException(400, f"Microsoft login error: {error}")
    if not code or not state:
        raise HTTPException(400, "Missing code/state")

    # valida o state
    state_cookie = request.cookies.get("ms_state")
    if not state_cookie or state_cookie != state:
        raise HTTPException(400, "Invalid state")

    app = _build_msal_app()
    result = app.acquire_token_by_authorization_code(
        code=code,
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI,
    )
    if "id_token_claims" not in result:
        # result pode conter "error", "error_description"
        raise HTTPException(401, f"Token exchange failed: {result.get('error_description', 'unknown')}")

    claims = result["id_token_claims"]
    # checa nonce (anti-replay)
    nonce_cookie = request.cookies.get("ms_nonce")
    if not nonce_cookie or claims.get("nonce") != nonce_cookie:
        raise HTTPException(400, "Invalid nonce")

    # dados úteis do usuário
    # emails possíveis: "email", "preferred_username", upn
    email = claims.get("email") or claims.get("preferred_username")
    name  = claims.get("name") or email
    oid   = claims.get("oid")  # object id no Entra ID

    if not email:
        raise HTTPException(400, "Email not provided by Microsoft account")

    # normaliza email
    email = email.strip().lower()

    # encontra ou cria usuário local
    user = db.query(User).filter(User.email == email).first()
    if not user:
        user = User(
            name=name,
            cpf=None,
            email=email,
            phone=None,
            status=UserStatus.pending,   # ou approved se você quiser auto-aprovar
            is_admin=False,
            password_hash="",            # não usa senha local
            valid_from=None,
            valid_to=None,
        )
        db.add(user); db.commit(); db.refresh(user)

    if user.status != UserStatus.approved:
        # opcional: renderize página “aguardando aprovação”
        raise HTTPException(403, "User not approved")

    # emite SEU JWT local (como já faz no /auth/login)
    token = create_access_token(user.id, user.is_admin)

    # redireciona p/ o front com o token (ou setar em cookie HttpOnly)
    resp = RedirectResponse(url=f"http://localhost:5173/auth/callback?token={token}")
    # se preferir cookie HttpOnly:
    # resp.set_cookie("access_token", token, httponly=True, secure=False, samesite="lax", max_age=8*3600)
    # resp = RedirectResponse(url="http://localhost:5173/")
    return resp
