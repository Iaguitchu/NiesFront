from fastapi import FastAPI
from routers.powerbi import router as powerbi_router
from routers.admin import router as admin
from routers.auth import router as auth
from routers.ms_login import router as ms_router


app = FastAPI()
app.include_router(powerbi_router)
app.include_router(admin )
app.include_router(auth)
app.include_router(ms_router)  # vai expor /auth/microsoft/login e /auth/microsoft/callback

from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
