from pydantic import BaseModel

class GroupOut(BaseModel):
    id: str
    name: str
    class Config:
        from_attributes = True

class GroupTreeOut(GroupOut):
    children: list["GroupTreeOut"] = []  # pydantic v2 suporta forward refs

GroupTreeOut.model_rebuild()

class ReportOut(BaseModel):
    id: str
    name: str
    thumbnail_url: str | None = None  # se for usar thumbs no front (opcional)
    class Config:
        from_attributes = True
