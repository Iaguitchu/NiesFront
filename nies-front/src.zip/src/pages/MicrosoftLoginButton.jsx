import MicrosoftLoginButton from "@/components/MicrosoftLoginButton";

function LoginPage() {
  return (
    <div className="h-screen flex items-center justify-center">
      <MicrosoftLoginButton />
    </div>
  );
}

export default LoginPage;
