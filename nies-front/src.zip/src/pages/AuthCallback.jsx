import { useEffect, useState } from "react";

export default function AuthCallback() {
  const [msg, setMsg] = useState("Processando login...");

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const token = params.get("token");
      const error = params.get("error");

      if (error) {
        setMsg(`Erro de login: ${error}`);
        return;
      }
      if (!token) {
        setMsg("Nenhum token recebido.");
        return;
      }

      // salve o token como você já faz no login normal
      localStorage.setItem("access_token", token);

      // redirecione para onde seu app espera
      setMsg("Autenticado! Redirecionando...");
      window.location.replace("/"); // ou /dashboard
    } catch (e) {
      setMsg("Falha ao processar o callback.");
      console.error(e);
    }
  }, []);

  return (
    <div className="h-screen flex items-center justify-center text-sm md:text-base">
      {msg}
    </div>
  );
}
