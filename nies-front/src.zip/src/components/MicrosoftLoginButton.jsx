export default function MicrosoftLoginButton({ className = "", label = "Entrar com Microsoft" }) {
  const apiBase = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8000";

  const handleClick = () => {
    // leva o usuário para o fluxo OAuth do backend
    window.location.href = `${apiBase}/auth/microsoft/login`;
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className={
        "inline-flex items-center gap-2 rounded-xl px-4 py-2 border transition " +
        "hover:shadow md:text-base text-sm " +
        "border-[#2F2F2F] bg-white text-[#2F2F2F] " +
        className
      }
      title={label}
    >
      {/* ícone simples */}
      <svg width="18" height="18" viewBox="0 0 23 23" aria-hidden>
        <rect width="10" height="10" x="1" y="1" fill="#F25022" />
        <rect width="10" height="10" x="12" y="1" fill="#7FBA00" />
        <rect width="10" height="10" x="1" y="12" fill="#00A4EF" />
        <rect width="10" height="10" x="12" y="12" fill="#FFB900" />
      </svg>
      {label}
    </button>
  );
}
